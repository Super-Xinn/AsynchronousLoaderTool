#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Kismet/BlueprintAsyncActionBase.h"
#include "UObject/SoftObjectPath.h"
#include "Engine/EngineTypes.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"
#include "AsynchronousLoadingToolBPLibrary.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FLevelLoadProgressPin, float, Progress);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FLevelLoadSimplePin);

UCLASS()
class ASYNCHRONOUSLOADINGTOOL_API UAsyncLoadLevelAction : public UBlueprintAsyncActionBase
{
    GENERATED_BODY()

public:
    
    UFUNCTION(BlueprintCallable, meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject", DisplayName = "AsyncLoadLevel"), Category = "AsynchronousLoadingTool")
    static UAsyncLoadLevelAction* AsyncLoadLevelWithMinTime(
        UObject* WorldContextObject,
        TSoftObjectPtr<UWorld> Level,
        float SmoothingSpeed = 3.0f,
        float MinDisplayTime = 2.0f,
        int32 DecimalPlaces = 3,
        bool bOpenImmediately = true
    );

    
    UFUNCTION(BlueprintCallable, Category = "AsynchronousLoadingTool", meta = (CallInEditor = "true", DisplayName = "打开关卡"))
    void OpenLevel();

    
    UPROPERTY(BlueprintAssignable, meta = (DisplayName = "On progress"))
    FLevelLoadProgressPin OnProgress;

    UPROPERTY(BlueprintAssignable)
    FLevelLoadSimplePin OnCompleted;

    virtual void Activate() override;

   
    virtual void SetReadyToDestroy() override;

private:
    void TickLoading();

    
    UPROPERTY()
    UObject* WorldContextPtr;

    FName TargetPackageName;
    FTimerHandle TimerHandle;

    float CurrentDisplayProgress = 0.0f;
    float TargetActualProgress = 0.0f;
    
    float InterpSpeed = 3.0f;
   
    float MinimumTime = 2.0f;
    
    UPROPERTY()
    int32 DecimalPlaces = 3;
    
    bool bOpenImmediately = true;
    double StartTime = 0.0;
    bool bLoadingFinished = false;
};

UCLASS()
class ASYNCHRONOUSLOADINGTOOL_API UAsynchronousLoadingToolBPLibrary : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()
};