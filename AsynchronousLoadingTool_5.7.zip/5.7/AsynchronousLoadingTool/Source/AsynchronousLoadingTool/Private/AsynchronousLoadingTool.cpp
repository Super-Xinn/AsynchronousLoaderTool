#include "AsynchronousLoadingTool.h"
#include "Modules/ModuleManager.h"
#include "UObject/UObjectGlobals.h" 
#include "Engine/Font.h"           

#define LOCTEXT_NAMESPACE "FAsynchronousLoadingToolModule"

void FAsynchronousLoadingToolModule::StartupModule()
{
    
    
    UFont* LoadedFont = Cast<UFont>(StaticLoadObject(UFont::StaticClass(), nullptr, TEXT("/AsynchronousLoadingTool/Fonts/NotoSans-Regular_Font.NotoSans-Regular_Font")));

    if (LoadedFont)
    {
        UE_LOG(LogTemp, Log, TEXT("AsynchronousLoadingTool: NotoSans Font Loaded Successfully!"));
    }
    else
    {
        
        UE_LOG(LogTemp, Warning, TEXT("AsynchronousLoadingTool: Failed to load NotoSans Font. Check your path!"));
    }
}

void FAsynchronousLoadingToolModule::ShutdownModule()
{
    
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FAsynchronousLoadingToolModule, AsynchronousLoadingTool)