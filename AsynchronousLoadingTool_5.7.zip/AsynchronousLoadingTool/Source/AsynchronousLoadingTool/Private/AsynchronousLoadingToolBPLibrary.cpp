#include "AsynchronousLoadingToolBPLibrary.h"
#include "UObject/UObjectGlobals.h"
#include "TimerManager.h"
#include "Engine/World.h"
#include "HAL/PlatformTime.h"

UAsyncLoadLevelAction* UAsyncLoadLevelAction::AsyncLoadLevelWithMinTime(UObject* WorldContextObject, FSoftObjectPath Level, float SmoothingSpeed, float MinDisplayTime)
{
    UAsyncLoadLevelAction* Action = NewObject<UAsyncLoadLevelAction>();
    Action->WorldContextPtr = WorldContextObject;
    Action->TargetPackageName = FName(*Level.GetLongPackageName());
    Action->InterpSpeed = SmoothingSpeed;
    Action->MinimumTime = MinDisplayTime;
    return Action;
}

void UAsyncLoadLevelAction::Activate()
{
    
    if (TargetPackageName.IsNone() || !IsValid(WorldContextPtr) || !WorldContextPtr->GetWorld())
    {
        OnCompleted.Broadcast();
        SetReadyToDestroy();
        return;
    }

    StartTime = FPlatformTime::Seconds();
    bLoadingFinished = false;
    CurrentDisplayProgress = 0.0f;
    TargetActualProgress = 0.0f;


    TWeakObjectPtr<UAsyncLoadLevelAction> WeakThis(this);

    LoadPackageAsync(TargetPackageName.ToString(),
        FLoadPackageAsyncDelegate::CreateLambda([WeakThis](const FName& PackageName, UPackage* LoadedPackage, EAsyncLoadingResult::Type Result)
            {
                if (UAsyncLoadLevelAction* StrongThis = WeakThis.Get())
                {
                    
                    StrongThis->bLoadingFinished = true;
                }
            }),
        0,
        PKG_ContainsMap
    );

    
    WorldContextPtr->GetWorld()->GetTimerManager().SetTimer(TimerHandle, this, &UAsyncLoadLevelAction::TickLoading, 0.016f, true);
}

void UAsyncLoadLevelAction::TickLoading()
{
    
    UWorld* World = IsValid(WorldContextPtr) ? WorldContextPtr->GetWorld() : nullptr;
    if (!World)
    {
        SetReadyToDestroy();
        return;
    }

    
    float RealPct = GetAsyncLoadPercentage(TargetPackageName);
    if (RealPct >= 0)
    {
        TargetActualProgress = RealPct / 100.0f;
    }

    
    float InterpTarget = bLoadingFinished ? 1.0f : TargetActualProgress;
    CurrentDisplayProgress = FMath::FInterpTo(CurrentDisplayProgress, InterpTarget, 0.016f, InterpSpeed);

    OnProgress.Broadcast(CurrentDisplayProgress);

    double ElapsedTime = FPlatformTime::Seconds() - StartTime;

    
    if (bLoadingFinished && ElapsedTime >= MinimumTime && (1.0f - CurrentDisplayProgress) < 0.005f)
    {
        OnProgress.Broadcast(1.0f);
        OnCompleted.Broadcast();

        
        World->GetTimerManager().ClearTimer(TimerHandle);

        
        SetReadyToDestroy();
    }
}

void UAsyncLoadLevelAction::SetReadyToDestroy()
{
    
    if (UWorld* World = IsValid(WorldContextPtr) ? WorldContextPtr->GetWorld() : nullptr)
    {
        World->GetTimerManager().ClearTimer(TimerHandle);
    }

    Super::SetReadyToDestroy();
}