using UnrealBuildTool;
using System.Collections.Generic;

public class AsynchronousLoadingTool : ModuleRules
{
    public AsynchronousLoadingTool(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        
        PublicDependencyModuleNames.AddRange(new string[]
        {
            "Core",
            "CoreUObject",
            "Engine",
            "InputCore"
        });

        
        PrivateDependencyModuleNames.AddRange(new string[]
        {
            "Slate",
            "SlateCore"
        });

       
        if (Target.Type == TargetType.Editor)
        {
            PrivateDependencyModuleNames.Add("Projects");
            PublicDependencyModuleNames.Add("UMG");
        }
    }
}