#include "AsynchronousLoadingTool.h"
#include "Modules/ModuleManager.h"

#if !UE_SERVER
#include "Engine/Font.h"
#include "UObject/UObjectGlobals.h"
#endif

#define LOCTEXT_NAMESPACE "FAsynchronousLoadingToolModule"

void FAsynchronousLoadingToolModule::StartupModule()
{
#if !UE_SERVER
    UFont* LoadedFont = Cast<UFont>(StaticLoadObject(UFont::StaticClass(), nullptr, TEXT("/AsynchronousLoadingTool/Fonts/My_Font54.My_Font54")));
    if (LoadedFont)
    {
        UE_LOG(LogTemp, Log, TEXT("AsynchronousLoadingTool: NotoSans Font Loaded Successfully!"));
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("AsynchronousLoadingTool: Failed to load NotoSans Font. Check your path!"));
    }
#endif
}

void FAsynchronousLoadingToolModule::ShutdownModule()
{
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FAsynchronousLoadingToolModule, AsynchronousLoadingTool)
