using UnrealBuildTool;

public class AsynchronousLoadingTool : ModuleRules
{
    public AsynchronousLoadingTool(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

        // 公共依赖模块，这些模块的头文件可在内部的 .h 中包含
        PublicDependencyModuleNames.AddRange(
            new string[]
            {
                "Core",
                "CoreUObject",
                "Engine",
                "InputCore",
                "UMG" 
            }
        );

        
        PrivateDependencyModuleNames.AddRange(
            new string[]
            {
                "Slate",
                "SlateCore",
                "Projects" 
            }
        );
    }
}