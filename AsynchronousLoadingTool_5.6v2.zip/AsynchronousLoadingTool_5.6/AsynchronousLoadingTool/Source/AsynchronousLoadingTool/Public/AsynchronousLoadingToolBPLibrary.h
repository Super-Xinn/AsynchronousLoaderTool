#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Kismet/BlueprintAsyncActionBase.h"
#include "UObject/SoftObjectPath.h"
#include "Engine/EngineTypes.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"
#include "AsynchronousLoadingToolBPLibrary.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FLevelLoadProgressPin, float, Progress);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FLevelLoadSimplePin);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FLevelLoadFailedPin);

UCLASS()
class ASYNCHRONOUSLOADINGTOOL_API UAsyncLoadLevelAction : public UBlueprintAsyncActionBase
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject", DisplayName = "AsyncLoadLevel"), Category = "AsynchronousLoadingTool")
    static UAsyncLoadLevelAction* AsyncLoadLevelWithMinTime(
        UObject* WorldContextObject,
        TSoftObjectPtr<UWorld> Level,
        UPARAM(DisplayName = "平滑阈值")
        float SmoothingSpeed = 3.0f,
        UPARAM(DisplayName = "最小打开时间")
        float MinDisplayTime = 2.0f,
        UPARAM(DisplayName = "返回值位数")
        int32 DecimalPlaces = 3,
        UPARAM(DisplayName = "立即打开")
        bool bOpenImmediately = true,
        UPARAM(DisplayName = "客户端预加载关卡包", meta = (ToolTip = "仅联机纯客户端(NM_Client)生效：开启则异步加载关卡包以减轻服务器旅行后的卡顿；关闭则只做最短展示时间的进度动画，不占用客户端 IO/内存。"))
        bool bPreloadPackageOnClient = true,
        UPARAM(DisplayName = "允许客户端打开关卡", meta = (ToolTip = "仅 NM_Client 生效：默认关闭（由服务器 ServerTravel）。若需客户端本地打开地图（如单机流程或特殊关卡），可开启。"))
        bool bAllowOpenLevelOnClient = false
    );

    UFUNCTION(BlueprintCallable, Category = "AsynchronousLoadingTool", meta = (CallInEditor = "true", DisplayName = "打开关卡"))
    void OpenLevel();

    UPROPERTY(BlueprintAssignable, meta = (DisplayName = "On progress"))
    FLevelLoadProgressPin OnProgress;

    UPROPERTY(BlueprintAssignable)
    FLevelLoadSimplePin OnCompleted;

    UPROPERTY(BlueprintAssignable, meta = (DisplayName = "On load failed"))
    FLevelLoadFailedPin OnLoadFailed;

    virtual void Activate() override;
    virtual void SetReadyToDestroy() override;

private:
    void TickLoading();

    UPROPERTY()
    UObject* WorldContextPtr;

    FName TargetPackageName;
    FTimerHandle TimerHandle;

    float CurrentDisplayProgress = 0.0f;
    float TargetActualProgress = 0.0f;
    float InterpSpeed = 3.0f;
    float MinimumTime = 2.0f;

    UPROPERTY()
    int32 DecimalPlaces = 3;

    bool bOpenImmediately = true;
    bool bPreloadPackageOnClient = true;
    bool bAllowOpenLevelOnClient = false;
    double StartTime = 0.0;
    bool bLoadingFinished = false;
    bool bNoPreloadClientFlow = false;
    bool bLoadFailed = false;
};

UCLASS()
class ASYNCHRONOUSLOADINGTOOL_API UAsynchronousLoadingToolBPLibrary : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()
};
