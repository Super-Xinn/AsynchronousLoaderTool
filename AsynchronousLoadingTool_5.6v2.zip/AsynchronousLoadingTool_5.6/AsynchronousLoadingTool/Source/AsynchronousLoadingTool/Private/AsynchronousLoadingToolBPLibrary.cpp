#include "AsynchronousLoadingToolBPLibrary.h"
#include "UObject/UObjectGlobals.h"
#include "TimerManager.h"
#include "Engine/World.h"
#include "HAL/PlatformTime.h"

UAsyncLoadLevelAction* UAsyncLoadLevelAction::AsyncLoadLevelWithMinTime(
    UObject* WorldContextObject,
    TSoftObjectPtr<UWorld> Level,
    float SmoothingSpeed,
    float MinDisplayTime,
    int32 DecimalPlaces,
    bool bOpenImmediately,
    bool bPreloadPackageOnClient,
    bool bAllowOpenLevelOnClient)
{
    UObject* Outer = IsValid(WorldContextObject) ? WorldContextObject : (UObject*)GetTransientPackage();

    UAsyncLoadLevelAction* Action = NewObject<UAsyncLoadLevelAction>(Outer);
    Action->WorldContextPtr = WorldContextObject;

    FSoftObjectPath LevelPath = Level.ToSoftObjectPath();
    if (LevelPath.IsValid())
    {
        Action->TargetPackageName = FName(*LevelPath.GetLongPackageName());
    }
    else
    {
        Action->TargetPackageName = NAME_None;
    }

    Action->InterpSpeed = SmoothingSpeed;
    Action->MinimumTime = MinDisplayTime;
    Action->DecimalPlaces = FMath::Clamp(DecimalPlaces, 2, 6);
    Action->bOpenImmediately = bOpenImmediately;
    Action->bPreloadPackageOnClient = bPreloadPackageOnClient;
    Action->bAllowOpenLevelOnClient = bAllowOpenLevelOnClient;
    return Action;
}

void UAsyncLoadLevelAction::Activate()
{
    if (TargetPackageName.IsNone())
    {
        UE_LOG(LogTemp, Warning, TEXT("AsyncLoadLevel: 关卡路径无效，请确保选择了有效的关卡资源"));
        OnLoadFailed.Broadcast();
        SetReadyToDestroy();
        return;
    }

    if (!IsValid(WorldContextPtr))
    {
        UE_LOG(LogTemp, Warning, TEXT("AsyncLoadLevel: WorldContext 无效"));
        OnLoadFailed.Broadcast();
        SetReadyToDestroy();
        return;
    }

    UWorld* World = WorldContextPtr->GetWorld();
    if (!World)
    {
        UE_LOG(LogTemp, Warning, TEXT("AsyncLoadLevel: 无法获取有效的 World"));
        OnLoadFailed.Broadcast();
        SetReadyToDestroy();
        return;
    }

    StartTime = FPlatformTime::Seconds();
    bLoadingFinished = false;
    bLoadFailed = false;
    bNoPreloadClientFlow = false;
    CurrentDisplayProgress = 0.0f;
    TargetActualProgress = 0.0f;

    const ENetMode NetMode = World->GetNetMode();
    const bool bIsPureClient = (NetMode == NM_Client);

    if (bIsPureClient && !bPreloadPackageOnClient)
    {
        bNoPreloadClientFlow = true;
        bLoadingFinished = true;
        TargetActualProgress = 1.0f;
        World->GetTimerManager().SetTimer(TimerHandle, this, &UAsyncLoadLevelAction::TickLoading, 0.016f, true);
        return;
    }

    TWeakObjectPtr<UAsyncLoadLevelAction> WeakThis(this);

    LoadPackageAsync(TargetPackageName.ToString(),
        FLoadPackageAsyncDelegate::CreateLambda([WeakThis](const FName& PackageName, UPackage* LoadedPackage, EAsyncLoadingResult::Type Result)
            {
                if (UAsyncLoadLevelAction* StrongThis = WeakThis.Get())
                {
                    if (Result == EAsyncLoadingResult::Succeeded && LoadedPackage)
                    {
                        StrongThis->bLoadingFinished = true;
                    }
                    else
                    {
                        StrongThis->bLoadFailed = true;
                        UE_LOG(LogTemp, Warning, TEXT("AsyncLoadLevel: 关卡包加载失败 Package=%s Result=%d"), *PackageName.ToString(), static_cast<int32>(Result));
                    }
                }
            }),
        0,
        PKG_ContainsMap
    );

    World->GetTimerManager().SetTimer(TimerHandle, this, &UAsyncLoadLevelAction::TickLoading, 0.016f, true);
}

void UAsyncLoadLevelAction::TickLoading()
{
    UWorld* World = IsValid(WorldContextPtr) ? WorldContextPtr->GetWorld() : nullptr;
    if (!World)
    {
        OnLoadFailed.Broadcast();
        SetReadyToDestroy();
        return;
    }

    if (bLoadFailed)
    {
        OnLoadFailed.Broadcast();
        World->GetTimerManager().ClearTimer(TimerHandle);
        SetReadyToDestroy();
        return;
    }

    float RealPct = GetAsyncLoadPercentage(TargetPackageName);
    if (RealPct >= 0)
    {
        TargetActualProgress = RealPct / 100.0f;
    }

    float InterpTarget = bLoadingFinished ? 1.0f : TargetActualProgress;
    CurrentDisplayProgress = FMath::FInterpTo(CurrentDisplayProgress, InterpTarget, 0.016f, InterpSpeed);
    float ClampedProgress = FMath::Clamp(CurrentDisplayProgress, 0.0f, 1.0f);
    const int32 Places = FMath::Clamp(DecimalPlaces, 2, 6);
    const float Scale = FMath::Pow(10.0f, static_cast<float>(Places));
    ClampedProgress = FMath::RoundToFloat(ClampedProgress * Scale) / Scale;

    OnProgress.Broadcast(ClampedProgress);

    double ElapsedTime = FPlatformTime::Seconds() - StartTime;

    if (bLoadingFinished && ElapsedTime >= MinimumTime && (1.0f - CurrentDisplayProgress) < 0.005f)
    {
        OnProgress.Broadcast(1.0f);
        OnCompleted.Broadcast();

        World->GetTimerManager().ClearTimer(TimerHandle);

        if (bOpenImmediately)
        {
            OpenLevel();
        }

        SetReadyToDestroy();
    }
}

void UAsyncLoadLevelAction::SetReadyToDestroy()
{
    if (UWorld* World = IsValid(WorldContextPtr) ? WorldContextPtr->GetWorld() : nullptr)
    {
        World->GetTimerManager().ClearTimer(TimerHandle);
    }

    Super::SetReadyToDestroy();
}

void UAsyncLoadLevelAction::OpenLevel()
{
    if (!IsValid(WorldContextPtr))
    {
        UE_LOG(LogTemp, Warning, TEXT("AsyncLoadLevel: 无法打开关卡，WorldContext 无效"));
        return;
    }

    UWorld* World = WorldContextPtr->GetWorld();
    if (!World)
    {
        UE_LOG(LogTemp, Warning, TEXT("AsyncLoadLevel: 无法打开关卡，World 无效"));
        return;
    }

    if (TargetPackageName.IsNone())
    {
        UE_LOG(LogTemp, Warning, TEXT("AsyncLoadLevel: 无法打开关卡，关卡路径无效"));
        return;
    }

    FString LevelName = TargetPackageName.ToString();
    ENetMode NetMode = World->GetNetMode();

    if (NetMode == NM_Client)
    {
        if (bAllowOpenLevelOnClient)
        {
            UE_LOG(LogTemp, Log, TEXT("AsyncLoadLevel: 客户端模式，使用 OpenLevel（AllowOpenLevelOnClient=true）: %s"), *LevelName);
            UGameplayStatics::OpenLevel(World, FName(*LevelName));
        }
        else
        {
            UE_LOG(LogTemp, Log, TEXT("AsyncLoadLevel: 客户端模式，跳过 OpenLevel（等待服务器 ServerTravel；或勾选 AllowOpenLevelOnClient）"));
        }
    }
    else if (NetMode == NM_ListenServer || NetMode == NM_DedicatedServer)
    {
        UE_LOG(LogTemp, Log, TEXT("AsyncLoadLevel: 服务器模式，使用 ServerTravel 切换关卡: %s"), *LevelName);
        World->ServerTravel(LevelName);
    }
    else
    {
        UE_LOG(LogTemp, Log, TEXT("AsyncLoadLevel: 单机模式，使用 OpenLevel 切换关卡: %s"), *LevelName);
        UGameplayStatics::OpenLevel(World, FName(*LevelName));
    }
}
